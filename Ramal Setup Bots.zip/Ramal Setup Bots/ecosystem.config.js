
const Sunucu_1 = "ramalpub";
module.exports = {
    apps: [
        {
            name: `${Sunucu_1}-RAMAL_3`,
            script: "./RAMAL_3/ramal.js",
            watch: false
        },
        {
            name: `${Sunucu_1}-RAMAL_6`,
            script: "./RAMAL_6/ramal.js",
            watch: false
        },
        {
            name: `${Sunucu_1}-RAMAL_5`,
            script: "./RAMAL_5/ramal.js",
            watch: false
        },
		{
            name: `${Sunucu_1}-RAMAL_1`,
            script: "./RAMAL_1/ramal.js",
            watch: true
        },
        {
            name: `${Sunucu_1}-RAMAL_4`,
            script: "./RAMAL_4/ramal.js",
            watch: false
        },
        {
            name: `${Sunucu_1}-RAMAL_2`,
            script: "./RAMAL_2/ramal.js",
            watch: false
        }
    ]
};
